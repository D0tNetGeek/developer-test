namespace OrangeBricks.Web.Controllers.Property.Commands
{
    public class ListPropertyCommand
    {
        public int PropertyId { get; set; }
    }
}